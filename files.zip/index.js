require('dotenv').config();
const path = require('path');
const fs = require('fs');
const { Client, GatewayIntentBits, Events } = require('discord.js');
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  entersState,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  NoSubscriberBehavior,
} = require('@discordjs/voice');
const googleTTS = require('google-tts-api');
const config = require('./config');

process.env.FFMPEG_PATH = require('ffmpeg-static');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates],
});

// ---------- State ----------
let connection = null;
let player = null;
let pendingWelcomes = 0; // how many welcome messages are still queued
let playingWelcome = false;

const musicPath = path.join(__dirname, config.MUSIC_FILE);

// ---------- Audio helpers ----------
function playMusic() {
  if (!fs.existsSync(musicPath)) {
    console.warn(`[!] Music file not found at ${musicPath} - skipping music.`);
    return;
  }
  const resource = createAudioResource(musicPath, { inlineVolume: true });
  resource.volume.setVolume(config.MUSIC_VOLUME);
  player.play(resource);
}

function playWelcome() {
  try {
    const url = googleTTS.getAudioUrl(config.WELCOME_MESSAGE, {
      lang: config.TTS_LANG,
      slow: false,
      host: 'https://translate.google.com',
    });
    const resource = createAudioResource(url, { inlineVolume: true });
    resource.volume.setVolume(config.WELCOME_VOLUME);
    playingWelcome = true;
    player.play(resource);
  } catch (err) {
    console.error('TTS error:', err);
    playingWelcome = false;
    playMusic();
  }
}

// Decides what to play next: queued welcome first, otherwise looping music
function playNext() {
  if (!player) return;
  if (pendingWelcomes > 0) {
    pendingWelcomes--;
    playWelcome();
  } else {
    playingWelcome = false;
    playMusic();
  }
}

// ---------- Connection helpers ----------
async function ensureConnected(guild, channel) {
  if (connection && connection.state.status !== VoiceConnectionStatus.Destroyed) return;

  connection = joinVoiceChannel({
    channelId: channel.id,
    guildId: guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: true,
  });

  player = createAudioPlayer({
    behaviors: { noSubscriber: NoSubscriberBehavior.Play },
  });

  player.on(AudioPlayerStatus.Idle, () => playNext());
  player.on('error', (err) => {
    console.error('Player error:', err.message);
    playNext();
  });

  connection.subscribe(player);

  connection.on(VoiceConnectionStatus.Disconnected, async () => {
    try {
      // Try to reconnect if Discord is just moving/reconnecting us
      await Promise.race([
        entersState(connection, VoiceConnectionStatus.Signalling, 5_000),
        entersState(connection, VoiceConnectionStatus.Connecting, 5_000),
      ]);
    } catch {
      cleanup();
    }
  });

  await entersState(connection, VoiceConnectionStatus.Ready, 20_000);
  console.log('Joined verification VC.');
}

function cleanup() {
  pendingWelcomes = 0;
  playingWelcome = false;
  if (player) {
    player.removeAllListeners();
    player.stop(true);
    player = null;
  }
  if (connection) {
    if (connection.state.status !== VoiceConnectionStatus.Destroyed) connection.destroy();
    connection = null;
  }
  console.log('Left verification VC.');
}

function humanCount(channel) {
  return channel.members.filter((m) => !m.user.bot).size;
}

async function handleJoin(guild, channel) {
  try {
    await ensureConnected(guild, channel);
  } catch (err) {
    console.error('Could not join VC:', err);
    cleanup();
    return;
  }
  pendingWelcomes++;
  // If we're not already in the middle of a welcome, interrupt the music and greet
  if (!playingWelcome) playNext();
}

// ---------- Events ----------
client.once(Events.ClientReady, async (c) => {
  console.log(`Logged in as ${c.user.tag}`);

  // If people are already in the VC when the bot starts, greet them
  try {
    const channel = await c.channels.fetch(config.VERIFICATION_VC_ID);
    if (channel && channel.isVoiceBased()) {
      const humans = channel.members.filter((m) => !m.user.bot);
      for (let i = 0; i < humans.size; i++) await handleJoin(channel.guild, channel);
    }
  } catch (err) {
    console.error('Startup check failed:', err.message);
  }
});

client.on(Events.VoiceStateUpdate, async (oldState, newState) => {
  const member = newState.member || oldState.member;
  if (!member || member.user.bot) return;

  const target = config.VERIFICATION_VC_ID;
  const joinedTarget = newState.channelId === target && oldState.channelId !== target;
  const leftTarget = oldState.channelId === target && newState.channelId !== target;

  if (joinedTarget) {
    await handleJoin(newState.guild, newState.channel);
  } else if (leftTarget) {
    // Person got moved out (or left) - disconnect if nobody is waiting anymore
    const channel = oldState.channel;
    if (channel && humanCount(channel) === 0) cleanup();
  }
});

process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));

client.login(process.env.DISCORD_TOKEN);
